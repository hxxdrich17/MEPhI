PITCHES = ["до", "ре", "ми", "фа", "соль", "ля", "си"]


class Note:
    def __init__(self, note, is_long=False):
        if is_long:
            if note == "до":
                self.note = "до-о"
            elif note == "ре":
                self.note = "ре-э"
            elif note == "ми":
                self.note = "ми-и"
            elif note == "фа":
                self.note = "фа-а"
            elif note == "соль":
                self.note = "со-оль"
            elif note == "ля":
                self.note = "ля-а"
            elif note == "си":
                self.note = "си-и"
        else:
            self.note = note

    def __str__(self):
        return self.note


class LoudNote(Note):
    def __str__(self):
        return self.note.upper()


class DefaultNote(Note):
    def __init__(self, note="до", is_long=False):
        super().__init__(note, is_long)


class NoteWithOctave(Note):
    def __init__(self, note, octave, is_long=False):
        super().__init__(note, is_long)
        self.octave = octave

    def __str__(self):
        return f"{self.note} ({self.octave})"


# print(Note("соль"))
# print(LoudNote(PITCHES[4]))
# print(DefaultNote("ми"))
# print(DefaultNote())
# print(DefaultNote(is_long=True))
# print(NoteWithOctave("ре", "первая октава"))
# print(NoteWithOctave("ля", "малая октава", is_long=True))
