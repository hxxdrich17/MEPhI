class Note:
    def __init__(self, note, long=False):
        if long:
            if note == "до":
                self.note = "до-о"
            elif note == "ре":
                self.note = "ре-э"
            elif note == "ми":
                self.note = "ми-и"
            elif note == "фа":
                self.note = "фа-а"
            elif note == "соль":
                self.note = "со-оль"
            elif note == "ля":
                self.note = "ля-а"
            elif note == "си":
                self.note = "си-и"
        else:
            self.note = note

    def __str__(self):
        return self.note


# do_1 = Note("до", False)
# doo = Note("до", True)
# do_2 = Note("до")
# print(do_1, doo, do_2)
