import copy

import pygame


class Board:
    # создание поля
    def __init__(self, width, height):
        self._width = width
        self._height = height
        self._board = [[0] * width for _ in range(height)]
        # значения по умолчанию
        self._left = 25
        self._top = 25
        self._cell_size = 50

    def set_view(self, left, top, cell_size):
        self._left = left
        self._top = top
        self._cell_size = cell_size

    def render(self, screen):
        screen.fill(pygame.Color("black"))

        for col in range(self._width):
            for row in range(self._height):
                pygame.draw.rect(screen, pygame.Color(64, 64, 64),
                                 (self._left + col * self._cell_size,
                                 self._top + row * self._cell_size,
                                 self._cell_size, self._cell_size), 1)

    def _get_cell(self, mouse_pos):
        if (self._left < mouse_pos[0] < (self._left + self._width * self._cell_size)) and \
                (self._top < mouse_pos[1] < (self._top + self._height * self._cell_size)):
            col = (mouse_pos[0] - self._left) // self._cell_size
            row = (mouse_pos[1] - self._top) // self._cell_size
            return col, row
        else:
            return None

    def on_click(self, cell_coords):
        pass

    def get_click(self, mouse_pos):
        cell = self._get_cell(mouse_pos)
        self.on_click(cell)


class Life(Board):
    def __init__(self, width, height):
        super().__init__(width, height)

    def on_click(self, cell_coords):
        self._board[cell_coords[1]][cell_coords[0]] = 1 if self._board[cell_coords[1]][cell_coords[0]] == 0 else 0

    def render(self, screen):
        super().render(screen)

        for col in range(self._width):
            for row in range(self._height):
                if self._board[row][col] == 1:
                    pygame.draw.rect(screen, pygame.Color("green"),
                                     (self._left + col * self._cell_size + 1, self._top + row * self._cell_size + 1,
                                      self._cell_size - 2, self._cell_size - 2))

    def next_move(self):
        tmp = copy.deepcopy(self._board)

        for col in range(self._width):
            for row in range(self._height):
                n = 0
                for c in range(col - 1, col + 2):
                    for r in range(row - 1, row + 2):
                        if c == col and r == row:
                            continue

                        if 0 <= c < self._width and 0 <= r < self._height:
                            if tmp[r][c] == 1:
                                n += 1

                if tmp[row][col] == 0:
                    self._board[row][col] = 1 if n == 3 else 0
                else:
                    self._board[row][col] = 1 if 1 < n <= 3 else 0


if __name__ == '__main__':
    pygame.init()
    pygame.display.set_caption("Игра ЖИЗНЬ")

    margin = 10
    cell_size = 15
    col_count = 40
    row_count = 30

    screen = pygame.display.set_mode((margin * 2 + cell_size * col_count, margin * 2 + cell_size * row_count))

    clock = pygame.time.Clock()
    fps = 10

    game = Life(col_count, row_count)
    game.set_view(margin, margin, cell_size)

    running = True
    active = False
    while running:
        # внутри игрового цикла ещё один цикл
        # приема и обработки сообщений
        for event in pygame.event.get():
            # при закрытии окна
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == pygame.BUTTON_LEFT:
                    game.get_click(event.pos)
                if event.button == pygame.BUTTON_RIGHT:
                    active = True
                if event.button == pygame.BUTTON_WHEELUP:
                    if fps < 60:
                        fps += 1
                if event.button == pygame.BUTTON_WHEELDOWN:
                    if fps > 5:
                        fps -= 1

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    active = not active

        if active:
            game.next_move()

        game.render(screen)

        clock.tick(fps)

        # обновление экрана
        pygame.display.flip()
