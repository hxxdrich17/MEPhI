import random
import pygame


class Board:
    # создание поля
    def __init__(self, width, height):
        self._width = width
        self._height = height
        self._board = [[-1] * width for _ in range(height)]
        # значения по умолчанию
        self._left = 25
        self._top = 25
        self._cell_size = 50

    def set_view(self, left, top, cell_size):
        self._left = left
        self._top = top
        self._cell_size = cell_size

    def render(self, screen):
        screen.fill(pygame.Color("black"))

        for col in range(self._width):
            for row in range(self._height):
                pygame.draw.rect(screen, pygame.Color(64, 64, 64),
                                 (self._left + col * self._cell_size,
                                 self._top + row * self._cell_size,
                                 self._cell_size, self._cell_size), 1)

    def _get_cell(self, mouse_pos):
        if (self._left < mouse_pos[0] < (self._left + self._width * self._cell_size)) and \
                (self._top < mouse_pos[1] < (self._top + self._height * self._cell_size)):
            col = (mouse_pos[0] - self._left) // self._cell_size
            row = (mouse_pos[1] - self._top) // self._cell_size
            return col, row
        else:
            return None

    def on_click(self, cell_coords):
        pass

    def get_click(self, mouse_pos):
        cell = self._get_cell(mouse_pos)
        self.on_click(cell)


class Minesweeper(Board):
    def __init__(self, width, height, mines_count):
        super().__init__(width, height)

        while mines_count > 0:
            r = random.randint(0, self._height - 1)
            c = random.randint(0, self._width - 1)

            if self._board[r][c] == -1:
                self._board[r][c] = 10
                mines_count -= 1

    def on_click(self, cell_coords):
        col = cell_coords[0]
        row = cell_coords[1]

        if self._board[row][col] >= 0:
            return

        n = 0
        for c in range(col - 1, col + 2):
            for r in range(row - 1, row + 2):
                if c == col and r == row:
                    continue

                if 0 <= c < self._width and 0 <= r < self._height:
                    if self._board[r][c] == 10:
                        n += 1

        self._board[row][col] = n

    def render(self, screen):
        super().render(screen)

        font = pygame.font.Font(None, 32)

        for col in range(self._width):
            for row in range(self._height):
                if self._board[row][col] == 10:
                    pygame.draw.rect(screen, pygame.Color("red"),
                                     (self._left + col * self._cell_size + 1, self._top + row * self._cell_size + 1,
                                      self._cell_size - 2, self._cell_size - 2))

                if 0 <= self._board[row][col] <= 9:
                    text = font.render(str(self._board[row][col]), True, pygame.Color(0, 192, 0))
                    screen.blit(text, (self._left + col * self._cell_size + 5, self._top + row * self._cell_size + 5))


if __name__ == '__main__':
    pygame.init()
    pygame.display.set_caption("Игра ЖИЗНЬ")

    margin = 10
    cell_size = 40
    col_count = 10
    row_count = 15

    screen = pygame.display.set_mode((margin * 2 + cell_size * col_count, margin * 2 + cell_size * row_count))

    clock = pygame.time.Clock()
    fps = 10

    game = Minesweeper(col_count, row_count, 20)
    game.set_view(margin, margin, cell_size)

    running = True
    while running:
        # внутри игрового цикла ещё один цикл
        # приема и обработки сообщений
        for event in pygame.event.get():
            # при закрытии окна
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == pygame.BUTTON_LEFT:
                    game.get_click(event.pos)

        game.render(screen)

        clock.tick(fps)

        # обновление экрана
        pygame.display.flip()