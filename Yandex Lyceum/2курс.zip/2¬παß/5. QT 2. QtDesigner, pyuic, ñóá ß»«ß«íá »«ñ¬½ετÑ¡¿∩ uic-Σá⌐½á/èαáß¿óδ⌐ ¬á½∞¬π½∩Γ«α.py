import sys
import math

from PyQt5 import uic
from PyQt5.QtWidgets import QApplication, QMainWindow


def calc(number1, operator, number2):
    if operator == "+":
        result = number1 + number2
    elif operator == "-":
        result = number1 - number2
    elif operator == "*":
        result = number1 * number2
    elif operator == "/":
        if number2 == 0:
            return "Err"
        result = number1 / number2
    elif operator == '^':
        result = number1 ** number2
    elif operator == "sqrt":
        if number1 < 0:
            return "Err"
        result = math.sqrt(number1)
    elif operator == '!':
        result = math.factorial(number1)
    else:
        result = 0.0

    if float(result).is_integer():
        return str(int(result))
    else:
        return f"{result:5.1f}"


class Window(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi("calc.ui", self)

        self.number = 0.0
        self.display_number = "0"
        self.operator = None
        self.new_number_flag = True

        self.buttonGroup_digits.buttonClicked.connect(self.on_digits_click)
        self.buttonGroup_binary.buttonClicked.connect(self.on_binary_click)
        self.btn_dot.clicked.connect(self.on_dot_click)
        self.btn_clear.clicked.connect(self.on_clear_click)
        self.btn_eq.clicked.connect(self.on_eq_click)
        self.btn_sqrt.clicked.connect(self.on_sqrt_click)
        self.btn_fact.clicked.connect(self.on_fact_click)

    def update_display(self):
        if len(self.display_number) > 5:
            self.error("OErr")
        else:
            self.table.display(self.display_number)

    def error(self, mgs):
        self.table.display(mgs)
        self.display_number = "0"
        self.operator = None
        self.new_number_flag = True

    def on_digits_click(self, btn):
        digit = btn.text()

        if self.new_number_flag:
            self.display_number = digit
            self.new_number_flag = False
        else:
            if len(self.display_number) < 5:
                if self.display_number == "0" and digit == "0":
                    pass
                else:
                    self.display_number = self.display_number + digit

        self.update_display()

    def on_dot_click(self):
        if len(self.display_number) < 4:
            self.display_number += self.sender().text() if "." not in self.display_number else ""

        self.table.display(self.display_number)

    def on_clear_click(self):
        self.number = 0.0
        self.display_number = "0"
        self.operator = None
        self.new_number_flag = True

        self.update_display()

    def on_binary_click(self, btn):
        if self.operator is not None:
            self.display_number = calc(self.number, self.operator, float(self.display_number))
            if self.display_number == "Err":
                self.error("Err")
                return None

        self.operator = btn.text()
        self.number = float(self.display_number)
        self.new_number_flag = True

        self.update_display()

    def on_eq_click(self):
        self.display_number = calc(self.number, self.operator, float(self.display_number))
        if self.display_number == "Err":
            self.error("Err")
            return None

        self.operator = None
        self.new_number_flag = True

        self.update_display()

    def on_sqrt_click(self):
        self.number = float(self.display_number)
        self.operator = "sqrt"

        self.on_eq_click()

    def on_fact_click(self):
        self.number = int(self.display_number)
        self.operator = "!"

        self.on_eq_click()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Window()
    ex.show()
    sys.exit(app.exec_())