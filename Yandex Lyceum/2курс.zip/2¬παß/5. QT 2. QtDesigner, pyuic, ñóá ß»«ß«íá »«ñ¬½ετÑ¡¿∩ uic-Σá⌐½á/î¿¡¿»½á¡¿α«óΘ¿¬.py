import sys

from PyQt5 import uic
from PyQt5.QtWidgets import QApplication, QMainWindow


class Window(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi("scheduler.ui", self)

        self.pushButton.clicked.connect(self.on_click)

    def on_click(self):
        date = f"{self.calendarWidget.selectedDate().toString('yyyy-MM-dd')} " \
               f"{self.timeEdit.time().toString('HH:mm:ss')}"

        for idx in range(self.listWidget.count()):
            if date < self.listWidget.item(idx).text().split(" - ")[0]:
                self.listWidget.insertItem(idx, f"{date} - {self.lineEdit.text()}")
                return None

        self.listWidget.addItem(f"{date} - {self.lineEdit.text()}")


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Window()
    ex.show()
    sys.exit(app.exec_())