import sys

from PyQt5 import uic 
from PyQt5.QtWidgets import QApplication, QMainWindow


class Window(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi("text_flag.ui", self)  # Загружаем дизайн

        self.btnCreatFlag.clicked.connect(self.on_click)

    def on_click(self):
        color1 = self.rbBlue1.text() if self.rbBlue1.isChecked() \
            else self.rbRed1.text() if self.rbRed1.isChecked() else self.rbGreen1.text()

        color2 = self.rbBlue2.text() if self.rbBlue2.isChecked() \
            else self.rbRed2.text() if self.rbRed2.isChecked() else self.rbGreen2.text()

        color3 = self.rbBlue3.text() if self.rbBlue3.isChecked() \
            else self.rbRed3.text() if self.rbRed3.isChecked() else self.rbGreen3.text()

        self.labelFlag.setText(f"Цвета: {color1}, {color2} и {color3}")


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Window()
    ex.show()
    sys.exit(app.exec_())