x1, y1, r1 = [int(v) for v in input().split()]
x2, y2, r2 = [int(v) for v in input().split()]

print("YES" if ((x1 - x2) ** 2 + (y1 - y2) ** 2) <= (r1 + r2) ** 2 else "NO")
