left1, top1, width1, height1 = [int(v) for v in input().split()]
left2, top2, width2, height2 = [int(v) for v in input().split()]


def line_cros(x11, x12, x21, x22):
    return x21 <= x11 <= x22 or x11 <= x21 <= x12


result = "NO"
if line_cros(left1, left1 + width1, left2, left2 + width2) and \
        line_cros(top1, top1 + height1, top2, top2 + height2):
    result = "YES"

print(result)
