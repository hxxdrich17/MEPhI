import sys

from PyQt5 import uic
from PyQt5.QtGui import QPixmap, QTransform
from PyQt5.QtWidgets import QApplication, QMainWindow


class Window(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi("PIL_2.0.ui", self)

        self.angle = 0
        self.pixmap = QPixmap("cat.png")
        self.img = self.pixmap.toImage()

        self.image.setPixmap(self.pixmap)

        self.pushButtonR.clicked.connect(self.on_click_channel)
        self.pushButtonG.clicked.connect(self.on_click_channel)
        self.pushButtonB.clicked.connect(self.on_click_channel)
        self.pushButtonAll.clicked.connect(self.on_click_channel)

        self.pushButtonRLeft.clicked.connect(self.on_click_rotate)
        self.pushButtonRRight.clicked.connect(self.on_click_rotate)

    def on_click_channel(self):
        mask_r = 1 if self.sender() is self.pushButtonR else 0
        mask_g = 1 if self.sender() is self.pushButtonG else 0
        mask_b = 1 if self.sender() is self.pushButtonB else 0

        self.img = self.pixmap.toImage()

        if self.sender() is not self.pushButtonAll:
            for x in range(self.img.width()):
                for y in range(self.img.height()):
                    color = self.img.pixelColor(x, y)
                    color.setRed(color.red() * mask_r)
                    color.setGreen(color.green() * mask_g)
                    color.setBlue(color.blue() * mask_b)
                    self.img.setPixelColor(x, y, color)

        self.image.setPixmap(QPixmap(self.img.transformed(QTransform().rotate(self.angle))))

    def on_click_rotate(self):
        if self.sender() is self.pushButtonRLeft:
            self.angle -= 90
        if self.sender() is self.pushButtonRRight:
            self.angle += 90

        self.image.setPixmap(QPixmap(self.img.transformed(QTransform().rotate(self.angle))))


if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    ex = Window()
    ex.show()
    sys.exit(app.exec_())