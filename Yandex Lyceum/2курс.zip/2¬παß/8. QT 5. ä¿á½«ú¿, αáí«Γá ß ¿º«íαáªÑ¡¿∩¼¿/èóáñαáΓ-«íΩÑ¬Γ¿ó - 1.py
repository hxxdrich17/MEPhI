from PyQt5.QtWidgets import QApplication, QWidget, QLineEdit, QLabel
from PyQt5.QtWidgets import QPushButton
from PyQt5.QtGui import QPainter, QColor
import sys


WIDTH = 480
HEIGHT = 640


class Example(QWidget):
    def __init__(self):
        super().__init__()
        self.paintSquare = False
        self.initUI()

    def initUI(self):
        self.setGeometry(100, 100, WIDTH, HEIGHT)
        self.setWindowTitle('Квадрат объектив - 1')
        self.btn = QPushButton(self)
        self.btn.setText('Показать')
        self.btn.move(10, 10)

        self.label_1 = QLabel(self)
        self.label_1.move(150, 10)
        self.label_1.setText('side')
        self.lineEdit_1 = QLineEdit(str(300), self)
        self.lineEdit_1.move(200, 10)

        self.label_2 = QLabel(self)
        self.label_2.move(150, 40)
        self.label_2.setText('coeff')
        self.lineEdit_2 = QLineEdit(str(0.9), self)
        self.lineEdit_2.move(200, 40)

        self.label_3 = QLabel(self)
        self.label_3.move(150, 70)
        self.label_3.setText('n')
        self.lineEdit_3 = QLineEdit(str(10), self)
        self.lineEdit_3.move(200, 70)

        self.btn.clicked.connect(self.draw)

    def draw(self):
        self.side = float(self.lineEdit_1.text())
        self.k = float(self.lineEdit_2.text())
        self.n = int(self.lineEdit_3.text())
        self.paintSquare = True
        self.update()

    def paintEvent(self, event):
        if self.paintSquare:
            painter = QPainter()
            painter.begin(self)
            painter.setPen(QColor(255, 0, 0))
            x_c, y_c = WIDTH // 2, int(HEIGHT - self.side // 2 - 50)

            for _ in range(self.n):
                side = int(self.side // 2)
                painter.drawLine(x_c - side, y_c - side, x_c + side, y_c - side)
                painter.drawLine(x_c + side, y_c - side, x_c + side, y_c + side)
                painter.drawLine(x_c - side, y_c + side, x_c + side, y_c + side)
                painter.drawLine(x_c - side, y_c - side, x_c - side, y_c + side)

                self.side *= self.k

            painter.end()
            self.paintSquare = False


if __name__ == '__main__':
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    ex = Example()
    ex.show()
    sys.exit(app.exec_())