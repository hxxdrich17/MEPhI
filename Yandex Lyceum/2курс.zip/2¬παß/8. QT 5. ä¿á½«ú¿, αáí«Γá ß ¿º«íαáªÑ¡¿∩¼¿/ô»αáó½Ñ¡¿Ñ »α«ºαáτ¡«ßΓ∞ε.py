import sys

from PyQt5.QtGui import QPixmap, QImage
from PyQt5.QtWidgets import QApplication, QLabel, QMainWindow, QSlider

SCREEN_SIZE = [400, 400]


class Example(QMainWindow):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setGeometry(400, 400, *SCREEN_SIZE)
        self.setWindowTitle('Изменение прозрачности')

        self.pixmap = QPixmap('cat.png')

        self.image = QLabel(self)
        self.image.move(100, 60)
        self.image.resize(250, 250)

        self.slider = QSlider(self)
        self.slider.move(10, 10)
        self.slider.resize(20, 380)
        self.slider.setMinimum(0)
        self.slider.setMaximum(255)
        self.slider.setValue(255)
        self.slider.valueChanged.connect(self.change_transparent)

        self.image.setPixmap(self.pixmap)

    def change_transparent(self):
        img = self.pixmap.toImage().convertToFormat(QImage.Format_ARGB32)
        for x in range(img.width()):
            for y in range(img.height()):
                color = img.pixelColor(x, y)
                color.setAlpha(int(self.slider.value()))

                img.setPixel(x, y, color.rgba())

        self.image.setPixmap(QPixmap(img))


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Example()
    ex.show()
    sys.exit(app.exec())