import os
import random
import sys

import pygame

pygame.init()
size = width, height = 500, 500
screen = pygame.display.set_mode(size)

fps = 60


def load_image(name, color_key=None):
    fullname = os.path.join('data', name)

    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        sys.exit()
    image = pygame.image.load(fullname)

    if color_key is not None:
        image = image.convert()
        if color_key == -1:
            color_key = image.get_at((0, 0))
        image.set_colorkey(color_key)
    else:
        image = image.convert_alpha()
    return image


class Hero(pygame.sprite.Sprite):
    image = load_image("creature.png")

    def __init__(self, *group):
        super().__init__(*group)
        self.image = Hero.image
        self.rect = self.image.get_rect()
        self.rect.x = random.randrange(width)
        self.rect.y = random.randrange(height)


if __name__ == '__main__':
    clock = pygame.time.Clock()

    all_sprites = pygame.sprite.Group()

    hero = Hero(all_sprites)

    step = 10
    running = True
    while running:
        screen.fill(pygame.Color("white"))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            key = pygame.key.get_pressed()
            if key[pygame.K_DOWN]:
                hero.rect.y += step
            elif key[pygame.K_UP]:
                hero.rect.y -= step
            elif key[pygame.K_LEFT]:
                hero.rect.x -= step
            elif key[pygame.K_RIGHT]:
                hero.rect.x += step

        all_sprites.draw(screen)

        clock.tick(fps)

        pygame.display.flip()
