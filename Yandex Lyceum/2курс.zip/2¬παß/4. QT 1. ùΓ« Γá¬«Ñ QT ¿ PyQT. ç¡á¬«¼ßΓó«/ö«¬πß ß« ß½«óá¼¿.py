import sys
from PyQt5.QtWidgets import QApplication, QWidget, QLineEdit, QPushButton


class Example(QWidget):
    def __init__(self):
        super().__init__()

        self.initUI()

    def initUI(self):
        self.setGeometry(100, 100, 320, 48)
        self.setWindowTitle('Фокус со словами')

        self.editWord1 = QLineEdit(self)
        self.editWord1.resize(120, 24)
        self.editWord1.move(8, 8)
        self.editWord1.setText("")

        self.editWord2 = QLineEdit(self)
        self.editWord2.resize(120, 24)
        self.editWord2.move(192, 8)
        self.editWord2.setText("")

        self.btnMoveWord = QPushButton("->", self)
        self.btnMoveWord.resize(48, 24)
        self.btnMoveWord.clicked.connect(self.moveWord)
        self.btnMoveWord.move(136, 8)

    def moveWord(self):
        if self.btnMoveWord.text() == "->":
            self.btnMoveWord.setText("<-")
            self.editWord2.setText(self.editWord1.text())
            self.editWord1.setText("")
        else:
            self.btnMoveWord.setText("->")
            self.editWord1.setText(self.editWord2.text())
            self.editWord2.setText("")


if __name__ == '__main__':
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    ex = Example()
    ex.show()
    sys.exit(app.exec())