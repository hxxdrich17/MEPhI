import sys
from PyQt5.QtWidgets import QApplication, QWidget, QLineEdit, QPushButton, QLabel


class Example(QWidget):
    def __init__(self):
        super().__init__()

        self.initUI()

    def initUI(self):
        self.setGeometry(100, 100, 320, 64)
        self.setWindowTitle('Вычисление выражений')

        self.label1 = QLabel('Выражение', self)
        self.label1.move(8, 8)

        self.label1 = QLabel('Результат', self)
        self.label1.move(192, 8)

        self.editExpression = QLineEdit(self)
        self.editExpression.resize(120, 24)
        self.editExpression.move(8, 32)
        self.editExpression.setText("")

        self.editResult = QLineEdit(self)
        self.editResult.resize(120, 24)
        self.editResult.move(192, 32)
        self.editResult.setText("")

        self.btnCalculate = QPushButton("->", self)
        self.btnCalculate.resize(48, 24)
        self.btnCalculate.clicked.connect(self.calculate)
        self.btnCalculate.move(136, 32)

    def calculate(self):
        self.editResult.setText(str(eval(self.editExpression.text())))


if __name__ == '__main__':
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    ex = Example()
    ex.show()
    sys.exit(app.exec())