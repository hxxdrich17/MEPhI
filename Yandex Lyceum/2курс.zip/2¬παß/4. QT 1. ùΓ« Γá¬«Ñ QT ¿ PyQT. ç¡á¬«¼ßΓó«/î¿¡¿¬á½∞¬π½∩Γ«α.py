import sys
import random
from PyQt5.QtWidgets import QApplication, QWidget, QLineEdit, QPushButton, QLCDNumber


class Example(QWidget):
    def __init__(self):
        super().__init__()

        self.initUI()

    def initUI(self):
        self.setGeometry(100, 100, 240, 320)
        self.setWindowTitle('Миникалькулятор')

        self.editNumber1 = QLineEdit(self)
        self.editNumber1.resize(224, 24)
        self.editNumber1.move(8, 8)
        self.editNumber1.setText("0")

        self.editNumber2 = QLineEdit(self)
        self.editNumber2.resize(224, 24)
        self.editNumber2.move(8, 36)
        self.editNumber2.setText("0")

        self.btnCalculate = QPushButton('Рассчитать', self)
        self.btnCalculate.resize(224, 36)
        self.btnCalculate.clicked.connect(self.calculate)
        self.btnCalculate.move(8, 64)

        self.LCD_sum = QLCDNumber(self)
        self.LCD_sum.resize(224, 36)
        self.LCD_sum.move(8, 120)

        self.LCD_sub = QLCDNumber(self)
        self.LCD_sub.resize(224, 36)
        self.LCD_sub.move(8, 164)

        self.LCD_mul = QLCDNumber(self)
        self.LCD_mul.resize(224, 36)
        self.LCD_mul.move(8, 208)

        self.LCD_div = QLCDNumber(self)
        self.LCD_div.resize(224, 36)
        self.LCD_div.move(8, 252)

    def calculate(self):
        a = int(self.editNumber1.text())
        b = int(self.editNumber2.text())

        self.LCD_sum.display(str(a + b))
        self.LCD_sub.display(str(a - b))
        self.LCD_mul.display(str(a * b))
        self.LCD_div.display(str(a // b) if b != 0 else "ERROR")


if __name__ == '__main__':
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    ex = Example()
    ex.show()
    sys.exit(app.exec())
