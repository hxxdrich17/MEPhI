import sys
from PyQt5.QtWidgets import QApplication, QWidget, QLineEdit, QCheckBox


class Example(QWidget):
    def __init__(self):
        super().__init__()

        self.initUI()

    def initUI(self):
        self.setGeometry(100, 100, 240, 136)
        self.setWindowTitle('Прятки для виджетов')

        self.cb1 = QCheckBox("edit1", self)
        self.cb1.setChecked(True)
        self.cb1.clicked.connect(self.check)
        self.cb1.move(8, 12)

        self.edit1 = QLineEdit("Поле edit1", self)
        self.edit1.resize(170, 24)
        self.edit1.move(64, 8)

        self.cb2 = QCheckBox("edit2", self)
        self.cb2.setChecked(True)
        self.cb2.clicked.connect(self.check)
        self.cb2.move(8, 44)

        self.edit2 = QLineEdit("Поле edit2", self)
        self.edit2.resize(170, 24)
        self.edit2.move(64, 40)

        self.cb3 = QCheckBox("edit3", self)
        self.cb3.setChecked(True)
        self.cb3.clicked.connect(self.check)
        self.cb3.move(8, 76)

        self.edit3 = QLineEdit("Поле edit3", self)
        self.edit3.resize(170, 24)
        self.edit3.move(64, 72)

        self.cb4 = QCheckBox("edit4", self)
        self.cb4.setChecked(True)
        self.cb4.clicked.connect(self.check)
        self.cb4.move(8, 108)

        self.edit4 = QLineEdit("Поле edit4", self)
        self.edit4.resize(170, 24)
        self.edit4.move(64, 104)

    def check(self):
        if self.sender().text() == "edit1":
            self.edit1.setVisible(self.sender().isChecked())
        elif self.sender().text() == "edit2":
            self.edit2.setVisible(self.sender().isChecked())
        elif self.sender().text() == "edit3":
            self.edit3.setVisible(self.sender().isChecked())
        elif self.sender().text() == "edit4":
            self.edit4.setVisible(self.sender().isChecked())


if __name__ == '__main__':
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    ex = Example()
    ex.show()
    sys.exit(app.exec())