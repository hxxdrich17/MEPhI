import pygame


def draw(screen):
    pygame.draw.line(screen, pygame.Color("white"), (0, 0), (width, height), width=5)
    pygame.draw.line(screen, pygame.Color("white"), (width, 0), (0, height), width=5)


if __name__ == '__main__':
    pygame.init()
    pygame.display.set_caption("Крест")

    size = width, height = [int(v) for v in input().split()]
    screen = pygame.display.set_mode(size)

    while pygame.event.wait().type != pygame.QUIT:
        draw(screen)
        pygame.display.flip()

    pygame.quit()
