import pygame

Colors = (pygame.Color("black"), pygame.Color("white"))


def draw(screen):
    screen.fill(pygame.Color("black"))
    side = (a // n)
    y = a - side
    for row in range(n):
        x = 0
        for col in range(n):
            color = Colors[(row + col) % 2]
            pygame.draw.rect(screen, color, (x, y, side, side), width=0)
            x += side
        y -= side


if __name__ == '__main__':
    pygame.init()
    pygame.display.set_caption("Шахматная клетка")

    try:
        a, n = [int(v) for v in input().split()]
    except ValueError:
        print("Неправильный формат ввода")
        exit(-1)
    screen = pygame.display.set_mode((a, a))

    draw(screen)
    pygame.display.flip()
    while pygame.event.wait().type != pygame.QUIT:
        pass

    pygame.quit()