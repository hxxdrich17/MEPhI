import pygame

Colors = (pygame.Color("blue"), pygame.Color("red"), pygame.Color("green"))


def draw(screen):
    screen.fill(pygame.Color("black"))

    number = n
    r = w * number
    center = (r, r)
    while number > 0:
        pygame.draw.circle(screen, Colors[number % 3], center, r, width=0)
        number -= 1
        r -= w


if __name__ == '__main__':
    pygame.init()
    pygame.display.set_caption("Мишень")

    try:
        w, n = [int(v) for v in input().split()]
    except ValueError:
        print("Неправильный формат ввода")
        exit(-1)

    screen = pygame.display.set_mode((2 * w * n, 2 * w * n))

    draw(screen)
    pygame.display.flip()
    while pygame.event.wait().type != pygame.QUIT:
        pass

    pygame.quit()