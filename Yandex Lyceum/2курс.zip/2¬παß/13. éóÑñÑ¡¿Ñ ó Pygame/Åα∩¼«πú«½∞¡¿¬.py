import pygame


def draw(screen):
    screen.fill(pygame.Color("black"))
    pygame.draw.rect(screen, pygame.Color("red"), (1, 1, width-1, height-1), width=0)


if __name__ == '__main__':
    pygame.init()
    pygame.display.set_caption("Прямоугольник")

    size = width, height = [int(v) for v in input().split()]
    screen = pygame.display.set_mode(size)

    while pygame.event.wait().type != pygame.QUIT:
        draw(screen)
        pygame.display.flip()

    pygame.quit()