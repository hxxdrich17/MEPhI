import sqlite3


db_name = input()
connection = sqlite3.connect(db_name)
cursor = connection.cursor()

rows = cursor.execute("""
    SELECT DISTINCT f.year 
    FROM films f
    WHERE f.title LIKE "Х%"
""").fetchall()

connection.close()

print(*map(lambda x: x[0], rows), sep='\n')
