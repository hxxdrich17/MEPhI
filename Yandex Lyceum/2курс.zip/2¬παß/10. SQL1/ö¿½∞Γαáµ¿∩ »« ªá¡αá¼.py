import sqlite3
import sys

from PyQt5 import uic
from PyQt5.QtWidgets import QApplication, QMainWindow, QTableWidgetItem


class MyWidget(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('films_filter.ui', self)
        self.params = {}
        self.con = sqlite3.connect("films_db.sqlite")
        self.select_genres()
        self.pushButton.clicked.connect(self.select)
        self.setWindowTitle('Фильтрация по жанрам')
        self.execute_query_and_fill_table("SELECT title, genre, year FROM films")

    def select_genres(self):
        req = "SELECT * from genres"
        cur = self.con.cursor()
        for value, key in cur.execute(req).fetchall():
            self.params[key] = value
        self.comboBox.addItems(list(self.params.keys()))

    def select(self):
        req = "SELECT title, genre, year FROM films WHERE genre = {}".format(
            self.params.get(self.comboBox.currentText()))
        self.execute_query_and_fill_table(req)

    def execute_query_and_fill_table(self, query):
        cur = self.con.cursor()
        result = cur.execute(query).fetchall()
        self.tableWidget.setRowCount(len(result))
        self.tableWidget.setColumnCount(len(result[0]))
        self.tableWidget.setHorizontalHeaderLabels(["Название", "Жанр", "Год"])
        for i, elem in enumerate(result):
            for j, val in enumerate(elem):
                self.tableWidget.setItem(i, j, QTableWidgetItem(str(val)))


def except_hook(cls, exception, traceback):
    sys.__excepthook__(cls, exception, traceback)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    sys.excepthook = except_hook
    ex = MyWidget()
    ex.show()
    sys.exit(app.exec())
