import sqlite3


db_name = input()
connection = sqlite3.connect(db_name)
cursor = connection.cursor()

rows = cursor.execute("""
    SELECT f.title 
    FROM films f
    WHERE f.genre = (SELECT g.id FROM genres g WHERE g.title IN ('музыка', 'анимация')) AND f.year >= 1997
""").fetchall()

connection.close()

print(*map(lambda x: x[0], rows), sep='\n')
