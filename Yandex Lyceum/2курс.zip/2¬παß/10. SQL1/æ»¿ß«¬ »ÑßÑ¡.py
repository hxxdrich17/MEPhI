import sqlite3


db_name = "music_db.sqlite"
connection = sqlite3.connect(db_name)
cursor = connection.cursor()

artist = input()

rows = cursor.execute(f"""
SELECT DISTINCT t.Name FROM Track t
  JOIN Album a ON t.AlbumId = a.AlbumId
  JOIN Artist ar ON ar.ArtistId = a.ArtistId
  WHERE ar.Name = '{artist}'
  ORDER BY t.name
""").fetchall()

connection.close()

print(*map(lambda x: x[0], rows), sep='\n')