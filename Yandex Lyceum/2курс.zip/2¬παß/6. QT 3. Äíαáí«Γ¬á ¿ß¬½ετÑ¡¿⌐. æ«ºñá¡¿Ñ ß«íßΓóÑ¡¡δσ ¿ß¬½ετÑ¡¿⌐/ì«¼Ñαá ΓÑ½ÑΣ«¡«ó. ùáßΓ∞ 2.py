def get_phone(phone):
    phone = "".join(phone.split())

    if all(phone.split("-")):
        phone = phone.replace("-", "")
    else:
        raise ValueError("недопускается наличие знаков '-' подряд или в начале или в конце номера")

    if phone[0] == "8":
        phone = "+7" + phone[1:]
    elif phone[:2] == "+7":
        pass
    else:
        raise ValueError("Номер должен начинаться с +7 или 8")

    bracket_begin_pos = phone.find("(")
    bracket_end_pos = phone.find(")")

    if phone.count("(") > 1 or phone.count(")") > 1:
        raise ValueError("Допускается максимум одна пара скобок")

    if bracket_begin_pos * bracket_end_pos < 0:
        raise ValueError("Непарные скобки")

    if bracket_begin_pos > bracket_end_pos:
        raise ValueError("Ошибка расстановки скобок")

    phone = phone.replace("(", "").replace(")", "")

    if not phone[1:].isnumeric():
        raise ValueError("В номере допускаются только цифры 0..9")

    if len(phone) != 12:
        raise ValueError("Число цифр в номере должно быть равно 11")

    return phone


if __name__ == '__main__':
    try:
        print(get_phone(input()))
    except ValueError:
        print("error")
