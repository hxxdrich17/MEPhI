def get_phone(phone):
    # Удаление пробелов
    phone = "".join(phone.split())

    # Если в номере телефона есть идущие подряд символы "-" (либо если строка начинается
    # или заканчивается на "-"), то в возврате split будут пустыте строки,
    # а all возвращает True только тогда, когда все агрументы можно интепретировать как True
    if all(phone.split("-")):
        phone = phone.replace("-", "")
    else:
        return "error"

    if phone[0] == "8":
        phone = "+7" + phone[1:]
    elif phone[:2] == "+7":
        pass
    else:
        return "error"

    bracket_begin_pos = phone.find("(")
    bracket_end_pos = phone.find(")")

    if phone.count("(") > 1 or phone.count(")") > 1:
        return "error"

    if bracket_begin_pos * bracket_end_pos < 0:
        return "error"

    if bracket_begin_pos > bracket_end_pos:
        return "error"

    phone = phone.replace("(", "").replace(")", "")

    if not phone[1:].isnumeric():
        return "error"

    if len(phone) != 12:
        return "error"

    return phone if phone[1:].isnumeric() else "error"


if __name__ == '__main__':
    print(get_phone(input()))
