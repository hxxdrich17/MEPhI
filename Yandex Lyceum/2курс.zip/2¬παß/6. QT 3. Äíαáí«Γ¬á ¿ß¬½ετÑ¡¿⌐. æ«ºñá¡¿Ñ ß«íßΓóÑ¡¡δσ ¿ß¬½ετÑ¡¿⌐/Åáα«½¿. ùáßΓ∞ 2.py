class PasswordError(Exception):
    pass


class LengthError(PasswordError):
    pass


class LetterError(PasswordError):
    pass


class DigitError(PasswordError):
    pass


class SequenceError(PasswordError):
    pass


def check_password(password):
    err_chs = [
        '123', '234', '345', '456', '567', '678', '789', '890',
        'qwe', 'wer', 'ert', 'rty', 'tyu', 'yui', 'uio', 'iop',
        'asd', 'sdf', 'dfg', 'fgh', 'ghj', 'hjk', 'jkl',
        'zxc', 'xcv', 'cvb', 'vbn', 'bnm',
        'йцу', 'цук', 'уке', 'кен', 'енг', 'нгш', 'гшщ', 'шщз', 'щзх', 'зхъ',
        'фыв', 'ыва', 'вап', 'апр', 'про', 'рол', 'олд', 'лдж', 'джэ',
        'ячс', 'чсм', 'сми', 'мит', 'ить', 'тьб', 'ьбю', 'жэё'
    ]

    if len(password) <= 8:
        raise LengthError

    if password.lower() == password or password.upper() == password:
        raise LetterError

    for n in "0123456789":
        if n in password:
            break
    else:
        raise DigitError

    password = password.lower()

    for chs in err_chs:
        if chs in password:
            raise SequenceError

    print("ok")


# try:
#     print(check_password("Password1"))
# except Exception as error:
#     print(error.__class__.__name__)
