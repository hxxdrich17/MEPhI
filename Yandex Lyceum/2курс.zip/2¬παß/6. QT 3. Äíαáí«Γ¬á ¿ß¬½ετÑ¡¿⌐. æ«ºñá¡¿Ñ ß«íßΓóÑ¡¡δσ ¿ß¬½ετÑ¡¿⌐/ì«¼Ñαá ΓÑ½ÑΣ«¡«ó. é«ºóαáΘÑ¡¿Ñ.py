def get_phone(phone):
    phone = "".join(phone.split())

    if all(phone.split("-")):
        phone = phone.replace("-", "")
    else:
        raise ValueError("неверный формат")

    if phone[0] == "8":
        phone = "+7" + phone[1:]
    elif phone[:2] == "+7":
        pass
    else:
        raise ValueError("неверный формат")

    bracket_begin_pos = phone.find("(")
    bracket_end_pos = phone.find(")")

    if phone.count("(") > 1 or phone.count(")") > 1:
        raise ValueError("неверный формат")

    if bracket_begin_pos * bracket_end_pos < 0:
        raise ValueError("неверный формат")

    if bracket_begin_pos > bracket_end_pos:
        raise ValueError("неверный формат")

    phone = phone.replace("(", "").replace(")", "")

    if not phone[1:].isnumeric():
        raise ValueError("неверный формат")

    if len(phone) != 12:
        raise ValueError("неверное количество цифр")

    return phone


if __name__ == '__main__':
    try:
        print(get_phone(input()))
    except ValueError as e:
        print(e)
