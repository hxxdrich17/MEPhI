def check(passwd):
    err_letters = [
        'qwe', 'wer', 'ert', 'rty', 'tyu', 'yui', 'uio', 'iop',
        'asd', 'sdf', 'dfg', 'fgh', 'ghj', 'hjk', 'jkl',
        'zxc', 'xcv', 'cvb', 'vbn', 'bnm',
        'йцу', 'цук', 'уке', 'кен', 'енг', 'нгш', 'гшщ', 'шщз', 'щзх', 'зхъ',
        'фыв', 'ыва', 'вап', 'апр', 'про', 'рол', 'олд', 'лдж', 'джэ',
        'ячс', 'чсм', 'сми', 'мит', 'ить', 'тьб', 'ьбю', 'жэё'
    ]

    if len(passwd) <= 8:
        return "error"

    if passwd.lower() == passwd or passwd.upper() == passwd:
        return "error"

    for n in "0123456789":
        if n in passwd:
            break
    else:
        return "error"

    passwd = passwd.lower()

    for letters in err_letters:
        if letters in passwd:
            return "error"

    # можно так
    # if any([letters in passwd for letters in err_letters]):
    #     return "error"

    return "ok"


if __name__ == '__main__':
    print(check(input()))
