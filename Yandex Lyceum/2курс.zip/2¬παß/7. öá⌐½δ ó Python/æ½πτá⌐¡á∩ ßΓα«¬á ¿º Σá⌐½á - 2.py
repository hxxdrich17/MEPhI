import sys

from PyQt5 import uic
from PyQt5.QtWidgets import QApplication, QMainWindow
from random import choice


class Window(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi("random_string.ui", self)

        self.pushButton.clicked.connect(self.on_click)

    def on_click(self):
        with open("lines.txt", mode="r", encoding="utf8") as f:
            self.lineEdit.setText(choice(f.readlines()).strip())


if __name__ == '__main__':
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    ex = Window()
    ex.show()
    sys.exit(app.exec_())