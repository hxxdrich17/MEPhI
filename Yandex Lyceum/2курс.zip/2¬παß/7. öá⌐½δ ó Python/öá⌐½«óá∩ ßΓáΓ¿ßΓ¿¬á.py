import sys

from PyQt5 import uic
from PyQt5.QtWidgets import QApplication, QMainWindow


class Window(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi("stats.ui", self)

        self.pushButton.clicked.connect(self.on_click)

    def on_click(self):
        with open("output.txt", mode="w", encoding="utf8") as f_out:
            with open("input.txt", mode="r", encoding="utf8") as f_in:
                numbers = [int(value) for value in f_in.read().split()]
                self.lineEdit.setText(str(max(numbers)))
                self.lineEdit_2.setText(str(min(numbers)))
                self.lineEdit_3.setText(str(sum(numbers) / len(numbers)))

                f_out.write(f"Максимальное значение: {max(numbers)}\n"
                            f"Минимальное значение: {min(numbers)}\n"
                            f"Среднее значение: {sum(numbers) / len(numbers)}")


if __name__ == '__main__':
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    ex = Window()
    ex.show()
    sys.exit(app.exec_())