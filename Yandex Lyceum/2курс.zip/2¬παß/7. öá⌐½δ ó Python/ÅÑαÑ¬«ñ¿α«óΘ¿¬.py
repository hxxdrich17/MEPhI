table = {"й": "j", "ц": "c", "у": "u", "к": "k", "е": "e", "н": "n",
         "г": "g", "ш": "sh", "щ": "shh", "з": "z", "х": "h", "ъ": "#",
         "ф": "f", "ы": "y", "в": "v", "а": "a", "п": "p", "р": "r",
         "о": "o", "л": "l", "д": "d", "ж": "zh", "э": "je", "я": "ya",
         "ч": "ch", "с": "s", "м": "m", "и": "i", "т": "t", "ь": "'",
         "б": "b", "ю": "ju", "ё": "jo"}

with open("transliteration.txt", mode="w", encoding="utf-8") as out_file:
    with open("cyrillic.txt", mode="r", encoding="utf-8") as in_file:
        for ch in in_file.read():
            try:
                if ch.isupper():
                    out_file.write(table[ch.lower()].upper())
                else:
                    out_file.write(table[ch])
            except KeyError:
                out_file.write(ch)
