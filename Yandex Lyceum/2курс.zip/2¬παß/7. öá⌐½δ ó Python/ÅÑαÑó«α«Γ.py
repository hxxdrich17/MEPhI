def reverse():
    with open("output.dat", mode="wb") as out_file:
        with open("input.dat", mode="rb") as in_file:
            out_file.write(in_file.read()[::-1])


reverse()
