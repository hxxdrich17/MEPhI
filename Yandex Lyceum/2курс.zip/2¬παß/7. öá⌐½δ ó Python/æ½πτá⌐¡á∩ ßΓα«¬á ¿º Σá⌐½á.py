from random import choice

f = open("lines.txt", encoding="utf8")
lines = f.readlines()
f.close()

if lines:
    print(choice(lines).strip())


