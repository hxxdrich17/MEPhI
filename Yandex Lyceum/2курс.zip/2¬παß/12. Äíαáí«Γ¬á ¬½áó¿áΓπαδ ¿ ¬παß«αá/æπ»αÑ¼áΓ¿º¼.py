import sys
from random import randint

from PyQt5 import QtGui
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QPainter, QColor
from PyQt5.QtWidgets import QMainWindow, QApplication


class Window(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setMouseTracking(True)
        self.coords_ = [0, 0]
        self.shape_id = -1

        self.setGeometry(100, 100, randint(300, 500), randint(300, 500))

    def paintEvent(self, event):
        qp = QPainter()
        qp.begin(self)

        x0 = self.coords_[0]
        y0 = self.coords_[1]

        qp.setBrush(QColor(randint(0, 255), randint(0, 255), randint(0, 255)))

        if self.shape_id == 1:
            r = randint(100, 200)
            qp.drawEllipse(x0 - (r // 2), y0 - (r // 2), r, r)
        elif self.shape_id == 2:
            a = randint(100, 200)
            qp.drawRect(x0 - (a // 2), y0 - (a // 2), a, a)
        elif self.shape_id == 3:
            pass

        qp.end()

    def mousePressEvent(self, a0: QtGui.QMouseEvent):
        if a0.button() == Qt.LeftButton:
            self.shape_id = 1
        elif a0.button() == Qt.RightButton:
            self.shape_id = 2

        self.update()

    def mouseMoveEvent(self, a0: QtGui.QMouseEvent):
        self.coords_ = [a0.x(), a0.y()]

    def keyPressEvent(self, a0: QtGui.QKeyEvent):
        self.shape_id = 3


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Window()
    ex.show()
    sys.exit(app.exec_())
