def shl(lst, n):
    return lst[n:] + lst[:n]


def shr(lst, n):
    return lst[-n:] + lst[:-n]


abc = input()
shift = int(input()) % len(abc)

if shift < 0:
    shift += len(abc)

print(shl(abc, shift))
print(abc)
print(shr(abc, shift))
