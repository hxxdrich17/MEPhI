from PIL import Image

image = Image.open('image.png')
pixels = image.load()
w, h = image.size

x0, y0, x1, y1 = w, h, 0, 0


for x in range(w):
    for y in range(h):
        if pixels[x, y] != pixels[0, 0]:
            if x < x0:
                x0 = x
            if x > x1:
                x1 = x
            if y < y0:
                y0 = y
            if y > y1:
                y1 = y

image.crop((x0, y0, x1 + 1, y1 + 1)).save('res.png')