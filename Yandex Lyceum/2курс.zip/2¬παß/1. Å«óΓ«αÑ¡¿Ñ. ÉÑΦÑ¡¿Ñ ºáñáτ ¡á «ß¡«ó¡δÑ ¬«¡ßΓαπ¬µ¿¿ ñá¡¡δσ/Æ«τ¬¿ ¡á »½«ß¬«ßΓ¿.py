points = list()
for _ in range(int(input())):
    x, y = [int(i) for i in input().split(' ')]
    points.append((x, y))

p1 = p2 = p3 = p4 = 0
for x, y in points:
    if x == 0 or y == 0:
        print(f"({x}, {y})")
    elif x > 0 and y > 0:
        p1 += 1
    elif x < 0 and y > 0:
        p2 += 1
    elif x < 0 and y < 0:
        p3 += 1
    else:
        p4 += 1

print(f"I: {p1}, II: {p2}, III: {p3}, IV: {p4}.")
