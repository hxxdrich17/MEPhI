persons = input().split(" -> ")
for _ in range(int(input())):
    index = persons.index(input())
    if index == 0:
        print(*persons[:2], sep=" -> ")
    else:
        print(*persons[index - 1: index + 2], sep=" -> ")
