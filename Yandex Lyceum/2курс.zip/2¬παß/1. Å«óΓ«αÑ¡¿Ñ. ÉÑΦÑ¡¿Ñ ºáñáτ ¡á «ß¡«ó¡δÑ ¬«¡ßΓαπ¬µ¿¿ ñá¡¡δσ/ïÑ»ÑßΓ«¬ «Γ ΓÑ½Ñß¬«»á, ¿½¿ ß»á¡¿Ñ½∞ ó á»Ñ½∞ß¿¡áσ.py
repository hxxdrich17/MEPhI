import sys

letters_orig = list(input())
out = list()

for word in [item.strip() for item in sys.stdin.readlines()]:
    letters = letters_orig[:]

    for letter in word.strip():
        if letter in letters:
            letters.remove(letter)
        else:
            break
    else:
        out.append(word)

print(len(out))
print(*out, sep="\n")

