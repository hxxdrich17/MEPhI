import pygame


if __name__ == '__main__':
    pygame.init()
    size = width, height = 800, 600
    screen = pygame.display.set_mode(size)

    v = 50
    fps = 60
    clock = pygame.time.Clock()
    circle_r = 1
    circle_pos = (0, 0)
    draw_circle = False

    screen.fill(pygame.Color("blue"))

    running = True
    while running:
        # внутри игрового цикла ещё один цикл
        # приема и обработки сообщений
        for event in pygame.event.get():
            # при закрытии окна
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.MOUSEBUTTONUP:
                screen.fill(pygame.Color("blue"))
                circle_pos = event.pos
                circle_r = 1
                draw_circle = True

        # отрисовка и изменение свойств объектов
        if draw_circle:
            pygame.draw.circle(screen, pygame.Color("yellow"), circle_pos, circle_r, 0)
            circle_r += v / fps

        clock.tick(fps)

        # обновление экрана
        pygame.display.flip()
    pygame.quit()