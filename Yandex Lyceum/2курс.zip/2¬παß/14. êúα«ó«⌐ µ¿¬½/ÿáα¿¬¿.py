import pygame


if __name__ == '__main__':
    pygame.init()
    size = width, height = 800, 600
    screen = pygame.display.set_mode(size)

    clock = pygame.time.Clock()
    fps = 60

    circle_radius = 10

    circle_count = 0
    circle_pos = []
    circle_v = []

    screen.fill(pygame.Color("black"))

    back_screen = pygame.Surface(screen.get_size())
    running = True
    while running:
        # внутри игрового цикла ещё один цикл
        # приема и обработки сообщений
        for event in pygame.event.get():
            # при закрытии окна
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.MOUSEBUTTONUP:
                circle_count += 1
                circle_pos.append(event.pos)
                circle_v.append([-100, -100])

        # отрисовка и изменение свойств объектов
        if circle_count > 0:
            back_screen.fill(pygame.Color("black"))
            for i in range(circle_count):
                pygame.draw.circle(back_screen, pygame.Color("white"), circle_pos[i], circle_radius, 0)
                x = circle_pos[i][0] + circle_v[i][0] / fps
                y = circle_pos[i][1] + circle_v[i][1] / fps

                if x < circle_radius:
                    circle_v[i][0] *= -1
                if x > width - circle_radius:
                    circle_v[i][0] *= -1
                if y < circle_radius:
                    circle_v[i][1] *= -1
                if y > height - circle_radius:
                    circle_v[i][1] *= -1

                circle_pos[i] = (x, y)

            screen.blit(back_screen, (0, 0))

        clock.tick(fps)

        # обновление экрана
        pygame.display.flip()
    pygame.quit()