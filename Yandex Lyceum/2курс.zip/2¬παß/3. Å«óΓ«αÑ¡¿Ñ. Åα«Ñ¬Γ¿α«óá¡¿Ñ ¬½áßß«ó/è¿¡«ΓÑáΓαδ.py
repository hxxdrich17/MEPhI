import datetime


class Hall:
    def __init__(self, title, seats):
        self.title = title
        self.seats = seats

    def print(self):
        for row in self.seats:
            for seat in row:
                if seat > 0:
                    print(f"[{seat:2}] ", end="")
                elif seat < 0:
                    print(f"[  ] ", end="")
                else:
                    print(f"     ", end="")
            print()


class Session:
    def __init__(self, hall, film, start, duration):
        self.hall = Hall(hall.title, [_[:] for _ in hall.seats])
        self.film = film
        self.start = start
        self.duration = duration

    def buy_ticket(self, seat_number):
        for row in self.hall.seats:
            for seat in row:
                if seat == seat_number:
                    row[row.index(seat)] = -1 * seat
                    return True

        return False

    def buy_tickets(self, *seat_numbers):
        for number in seat_numbers:
            self.buy_ticket(number)

    def print(self):
        print("--------------------------------")
        print("Фильм:", self.film)
        print("Зал:", self.hall.title)
        print("Начало:", self.start.strftime("%H:%M %d.%m.%Y"))
        print("Длительность:", self.duration, "минут")
        print()
        self.hall.print()
        print()


class Cinema:
    def __init__(self, title):
        self.title = title
        self.halls = dict()
        self.sessions = list()

    def add_hall(self, title, seats):
        self.halls[title] = Hall(title, seats)

    def add_session(self, hall, film, start, duration):
        session = Session(self.halls[hall], film, start, duration)
        self.sessions.append(session)

        return session

    def session(self, film, start):
        for session in self.sessions:
            if session.film == film and session.start == start:
                return session

        return None

    def find(self, film):
        sessions = sorted([session for session in self.sessions if session.film == film],
                          key=lambda x: x.start)
        for session in sessions:
            for row in session.hall.seats:
                for seat in row:
                    if seat > 0:
                        return session

        return None


class CinemaNetwork:
    def __init__(self):
        self.cinemas = dict()

    def add_cinema(self, cinema):
        self.cinemas[cinema.title] = cinema

    def __getitem__(self, key):
        return self.cinemas[key]

    def find(self, film):
        for cinema_title in self.cinemas:
            cinema = self.cinemas[cinema_title]

            session = cinema.find(film)
            if session:
                print("Кинотеатр:", cinema_title)
                session.print()

                return

        print("Сеансы не найдены")


cinema_network = CinemaNetwork()
cinema_network.add_cinema(Cinema("Звезда"))

cinema_network["Звезда"].add_hall("Зал 1", [[0, 1, 2, 3, 4, 0],
                                            [5, 6, 7, 8, 9, 10],
                                            [11, 12, 13, 14, 15, 16]])

cinema_network["Звезда"].add_hall("VIP", [[1, 2]])

cinema_network["Звезда"].add_session("Зал 1", "Побег из Шоушенка", datetime.datetime(2020, 9, 20, 10, 0, 0), 120)
cinema_network["Звезда"].add_session("VIP", "Крестный отец", datetime.datetime(2020, 9, 20, 19, 0, 0), 120)
cinema_network["Звезда"].add_session("VIP", "Крестный отец", datetime.datetime(2020, 9, 20, 22, 30, 0), 120)

cinema_network["Звезда"].session("Побег из Шоушенка", datetime.datetime(2020, 9, 20, 10, 0, 0)).buy_ticket(7)
cinema_network["Звезда"].session("Побег из Шоушенка", datetime.datetime(2020, 9, 20, 10, 0, 0)).buy_tickets(12, 13, 14)

cinema_network["Звезда"].session("Крестный отец", datetime.datetime(2020, 9, 20, 19, 0, 0)).buy_tickets(1, 2)
cinema_network["Звезда"].session("Крестный отец", datetime.datetime(2020, 9, 20, 22, 30, 0)).buy_tickets(2)

cinema_network.find("Крестный отец")
