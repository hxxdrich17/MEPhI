N = 7
PITCHES = ["до", "ре", "ми", "фа", "соль", "ля", "си"]
LONG_PITCHES = ["до-о", "ре-э", "ми-и", "фа-а", "со-оль", "ля-а", "си-и"]
INTERVALS = ["прима", "секунда", "терция", "кварта", "квинта", "секста", "септима"]


class Note:
    def __init__(self, note, is_long=False):
        self.is_long = is_long
        self.note_index = PITCHES.index(note)

    def __str__(self):
        return LONG_PITCHES[self.note_index] if self.is_long else PITCHES[self.note_index]

    def __lt__(self, other):
        return self.note_index < other.note_index

    def __gt__(self, other):
        return self.note_index > other.note_index

    def __le__(self, other):
        return self.note_index <= other.note_index

    def __ge__(self, other):
        return self.note_index >= other.note_index

    def __ne__(self, other):
        return self.note_index != other.note_index

    def __eq__(self, other):
        return self.note_index == other.note_index

    def __lshift__(self, other):
        idx = (self.note_index - other) % N
        if idx < 0:
            idx = idx + N
        return Note(PITCHES[idx], self.is_long)

    def __rshift__(self, other):
        idx = (self.note_index + other) % N
        if idx >= N:
            idx = idx - N
        return Note(PITCHES[idx], self.is_long)

    def get_interval(self, note):
        return INTERVALS[abs(self.note_index - note.note_index)]


class Melody:
    def __init__(self, notes=None):
        self.notes = notes if notes else []

    def __str__(self):
        return ", ".join([str(note) for note in self.notes]).capitalize()

    def __len__(self):
        return len(self.notes)

    def replace_last(self, note):
        self.notes[-1] = note

    def remove_last(self):
        self.notes.pop()

    def append(self, note):
        self.notes.append(note)

    def clear(self):
        self.notes.clear()

    def __lshift__(self, other):
        for note in self.notes:
            if note.note_index - other < 0:
                return Melody(self.notes[:])

        return Melody([note << other for note in self.notes])

    def __rshift__(self, other):
        for note in self.notes:
            if note.note_index + other >= N:
                return Melody(self.notes[:])

        return Melody([note >> other for note in self.notes])


# melody = Melody([Note('ля'), Note('соль'), Note('ми'),  Note('до', True)])
# print(melody)
# print(Melody() >> 2)
# melody_up = melody >> 1
# melody_down = melody << 1
# melody.replace_last(Note('соль'))
# print('>> 1:', melody_up)
# print('<< 1:', melody_down)
# print(melody)
