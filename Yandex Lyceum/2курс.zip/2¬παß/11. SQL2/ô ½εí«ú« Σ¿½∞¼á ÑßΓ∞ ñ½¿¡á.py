import sqlite3


def get_result(name):
    connection = sqlite3.connect(name)
    cursor = connection.cursor()

    cursor.execute("""
        UPDATE films 
        SET duration = 42
        WHERE duration IS NULL OR duration = "" 
    """)

    connection.commit()
    connection.close()


get_result(input())
