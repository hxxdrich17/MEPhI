import sqlite3


def get_result(name):
    connection = sqlite3.connect(name)
    cursor = connection.cursor()

    cursor.execute("""
        DELETE FROM films WHERE title LIKE "Я%а"
    """)

    connection.commit()
    connection.close()


get_result(input())
