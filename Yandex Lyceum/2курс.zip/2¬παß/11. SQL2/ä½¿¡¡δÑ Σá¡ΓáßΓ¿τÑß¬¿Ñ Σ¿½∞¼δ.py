import sqlite3


def get_result(name):
    connection = sqlite3.connect(name)
    cursor = connection.cursor()

    cursor.execute("""
        UPDATE films 
        SET duration = duration * 2
        WHERE genre = (SELECT id FROM genres WHERE title='фантастика')
    """)

    connection.commit()
    connection.close()


get_result(input())