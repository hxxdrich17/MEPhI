import sqlite3


def get_result(name):
    connection = sqlite3.connect(name)
    cursor = connection.cursor()

    cursor.execute("""
        DELETE FROM films
        WHERE genre = (SELECT id FROM genres WHERE title = "комедия")
    """)

    connection.commit()
    connection.close()


get_result(input())
