import pygame


class Board:
    # создание поля
    def __init__(self, width, height):
        self._width = width
        self._height = height
        self._board = [[0] * width for _ in range(height)]
        # значения по умолчанию
        self._left = 25
        self._top = 25
        self._cell_size = 50

    # настройка внешнего вида
    def set_view(self, left, top, cell_size):
        self._left = left
        self._top = top
        self._cell_size = cell_size

    def render(self, screen):
        for col in range(self._width):
            for row in range(self._height):
                pygame.draw.rect(screen, pygame.Color('white'),
                                 (self._left + col * self._cell_size,
                                 self._top + row * self._cell_size,
                                 self._cell_size, self._cell_size), 1)


if __name__ == '__main__':
    pygame.init()
    size = width, height = 640, 480
    screen = pygame.display.set_mode(size)

    clock = pygame.time.Clock()
    fps = 60

    board = Board(5, 7)

    running = True
    while running:
        # внутри игрового цикла ещё один цикл
        # приема и обработки сообщений
        for event in pygame.event.get():
            # при закрытии окна
            if event.type == pygame.QUIT:
                running = False

        screen.fill(pygame.Color("black"))
        board.render(screen)

        clock.tick(fps)

        # обновление экрана
        pygame.display.flip()