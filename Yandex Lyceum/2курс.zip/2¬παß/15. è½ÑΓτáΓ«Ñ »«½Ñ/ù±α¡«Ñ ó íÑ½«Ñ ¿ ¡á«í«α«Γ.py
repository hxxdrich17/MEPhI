import pygame


class Board:
    # создание поля
    def __init__(self, width, height):
        self._width = width
        self._height = height
        self._board = [[0] * width for _ in range(height)]
        # значения по умолчанию
        self._left = 25
        self._top = 25
        self._cell_size = 50

    # настройка внешнего вида
    def set_view(self, left, top, cell_size):
        self._left = left
        self._top = top
        self._cell_size = cell_size

    def render(self, screen):
        for col in range(self._width):
            for row in range(self._height):
                pygame.draw.rect(screen, pygame.Color('white'),
                                 (self._left + col * self._cell_size,
                                 self._top + row * self._cell_size,
                                 self._cell_size, self._cell_size), 1)

                if self._board[row][col] == 1:
                    pygame.draw.rect(screen,
                                     pygame.Color('white'),
                                     (self._left + col * self._cell_size,
                                      self._top + row * self._cell_size, self._cell_size, self._cell_size))

    def _get_cell(self, mouse_pos):
        if (self._left < mouse_pos[0] < (self._left + self._width * self._cell_size)) and \
                (self._top < mouse_pos[1] < (self._top + self._height * self._cell_size)):
            col = (mouse_pos[0] - self._left) // self._cell_size
            row = (mouse_pos[1] - self._top) // self._cell_size
            return col, row
        else:
            return None

    def on_click(self, cell_coords):
        for col in range(self._width):
            if (col, cell_coords[1]) != cell_coords:
                self._board[cell_coords[1]][col] = 1 if self._board[cell_coords[1]][col] == 0 else 0

        for row in range(self._height):
            if (cell_coords[0], row) != cell_coords:
                self._board[row][cell_coords[0]] = 1 if self._board[row][cell_coords[0]] == 0 else 0

        self._board[cell_coords[1]][cell_coords[0]] = 1 if self._board[cell_coords[1]][cell_coords[0]] == 0 else 0

    def get_click(self, mouse_pos):
        cell = self._get_cell(mouse_pos)
        self.on_click(cell)


if __name__ == '__main__':
    pygame.init()
    size = width, height = 640, 480
    screen = pygame.display.set_mode(size)

    clock = pygame.time.Clock()
    fps = 60

    board = Board(5, 7)

    running = True
    while running:
        # внутри игрового цикла ещё один цикл
        # приема и обработки сообщений
        for event in pygame.event.get():
            # при закрытии окна
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                board.get_click(event.pos)

        screen.fill(pygame.Color("black"))
        board.render(screen)

        clock.tick(fps)

        # обновление экрана
        pygame.display.flip()