with open("res.bmp", mode="wb") as f_out:
    with open("input.bmp", mode="rb") as f_in:
        f_out.write(f_in.read(54))

        buf = list()
        for b in f_in.read():
            buf.append(255 - b)

        f_out.write(bytes(buf))
