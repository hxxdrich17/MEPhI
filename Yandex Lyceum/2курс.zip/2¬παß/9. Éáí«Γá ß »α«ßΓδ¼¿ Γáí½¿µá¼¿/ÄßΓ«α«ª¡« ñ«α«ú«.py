import sys
from PyQt5 import uic
from PyQt5.QtGui import QColor
from PyQt5.QtWidgets import QApplication, QMainWindow, QTableWidgetItem, QHeaderView, QPushButton
import csv
from random import randint


class Window(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi("interactive_check_1.ui", self)

        self.goods = dict()
        self.loadTable('price.csv')
        self.tableWidget.cellChanged.connect(self.on_change)
        self.pushButton.clicked.connect(self.on_click)

    def loadTable(self, table_name):
        with open(table_name, encoding="utf8") as csvfile:
            reader = csv.reader(csvfile, delimiter=';', quotechar='"')
            next(reader)

            title = ('Название', 'Цена', 'Количество')

            self.tableWidget.setColumnCount(len(title))
            header = self.tableWidget.horizontalHeader()
            header.setSectionResizeMode(0, QHeaderView.Stretch)
            header.setSectionResizeMode(1, QHeaderView.ResizeToContents)
            header.setSectionResizeMode(2, QHeaderView.ResizeToContents)

            self.tableWidget.setHorizontalHeaderLabels(title)

            self.tableWidget.setRowCount(0)
            for i, row in enumerate(reader):
                self.goods[row[0]] = (i, int(row[1]))
                self.tableWidget.setRowCount(self.tableWidget.rowCount() + 1)
                for j, elem in enumerate(row):
                    self.tableWidget.setItem(i, j, QTableWidgetItem(elem))
                self.tableWidget.setItem(i, 2, QTableWidgetItem('0'))

    def color_row(self, row, color):
        for i in range(self.tableWidget.columnCount()):
            self.tableWidget.item(row, i).setBackground(color)

    def on_change(self, row, column):
        total = 0
        for row in range(self.tableWidget.rowCount()):
            total += int(self.tableWidget.item(row, 1).text()) * int(self.tableWidget.item(row, 2).text())

        self.lineEdit.setText(str(total))

    def on_click(self):
        for i, item in enumerate(sorted(self.goods, key=lambda x: self.goods[x][1], reverse=True)):
            if i < 5:
                self.color_row(self.goods[item][0], QColor(randint(0, 255), randint(0, 255),  randint(0, 255)))


if __name__ == '__main__':
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    ex = Window()
    ex.show()
    sys.exit(app.exec_())
