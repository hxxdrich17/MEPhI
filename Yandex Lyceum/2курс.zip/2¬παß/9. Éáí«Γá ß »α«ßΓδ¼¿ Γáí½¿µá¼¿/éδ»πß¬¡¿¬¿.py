import csv

data = int(input())

with open('vps.csv', encoding="utf-8") as csvfile:
    for i, row in enumerate(csv.reader(csvfile, delimiter=';', quotechar='"')):
        if i > 0:
            if int(row[4]) >= data:
                print(row[0])
