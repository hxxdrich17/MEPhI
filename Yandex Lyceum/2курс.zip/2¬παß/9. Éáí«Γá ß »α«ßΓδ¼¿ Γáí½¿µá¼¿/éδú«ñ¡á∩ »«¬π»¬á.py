import csv

cash = 1000

goods = dict()
with open('wares.csv', encoding="utf-8") as csvfile:
    for row in csv.reader(csvfile, delimiter=';', quotechar='"'):
        goods[row[0]] = int(row[1])

result = list()
for key in sorted(goods, key=lambda x: goods[x]):
    price = goods[key]
    n = 10
    while cash - price >= 0 and n > 0:
        cash -= price
        result.append(key)
        n -= 1

print(", ".join(result) if result else "error")
